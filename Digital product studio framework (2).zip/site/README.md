# Ship Sight — Static Website

Two self-contained pages, ready to host on any static server.

## Files
- `index.html` — Home / landing page
- `dashboard.html` — Live analytics dashboard demo

Both files are fully self-contained (fonts, styles, and scripts are inlined).
No build step, no dependencies, no internet required to render.

## How to deploy

Pick any one — all work with these files as-is:

### Netlify (drag & drop)
1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page.
3. Done — you get a live URL instantly.

### Vercel
1. `npm i -g vercel`
2. Run `vercel` inside this folder and follow the prompts.

### GitHub Pages
1. Create a repo, push these files.
2. Settings → Pages → deploy from branch (root).

### Cloudflare Pages / Any host
Upload the folder to your host's static hosting. `index.html` is the entry point.

## Local preview
Just double-click `index.html`, or run:
```
npx serve .
```

## Notes
- Cross-page navigation is wired: the "Live Dashboard" link and the
  "Book Free Audit" buttons move between the two pages correctly.
- WhatsApp buttons are wired to +92 331 0412072.
- The Book Free Audit form is a front-end demo — connect it to your
  email/CRM endpoint before going live (see the Phase 6 dev handoff).
